

//1번문제 
var countA: Int = 0
var countT: Int = 0
var countG: Int = 0
var countC: Int = 0

let longStrand = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC"
print(longStrand)

for char in longStrand.characters {
    switch char {
    case "A":
        countA += 1
    case "T":
        countT += 1
    case "G":
        countG += 1
    case "C":
        countC += 1
    default :
        break
    }
}
  print("count result ; A:\(countA), T:\(countT), G:\(countG), C:\(countC) ")


